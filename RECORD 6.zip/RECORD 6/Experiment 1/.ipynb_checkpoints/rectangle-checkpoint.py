def rectangle(l,b):
    return l*b
def rectperi(l,b):
    return 2*(l+b)