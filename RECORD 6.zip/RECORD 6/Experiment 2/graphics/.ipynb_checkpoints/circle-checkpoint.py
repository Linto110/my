def c_e\area(r):
    return 3.14*r*r
def c_periarea(r):
    return 2*3.14*r