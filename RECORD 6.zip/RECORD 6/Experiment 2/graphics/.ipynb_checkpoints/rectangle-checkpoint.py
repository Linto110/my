def r_area(l,b):
    return l*b
def r_perimeter(l,b):
    return 2*(l+b)