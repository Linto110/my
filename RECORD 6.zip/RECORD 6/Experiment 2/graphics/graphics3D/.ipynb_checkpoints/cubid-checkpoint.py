def cubid_area(l,b,h):
    return 2*(l*b)+(l*h)+(b*h)