def cubid_area(l,b,h):
    return 2*(l*b+l*h+b*h)
def cubid_perimeter(l,b,h):
    return 4*(l+b+h)