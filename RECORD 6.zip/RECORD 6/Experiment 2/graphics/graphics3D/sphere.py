def Sphere_area(r):
    return 4*3.14*r
def circum_sphere(ra):
    return  2*3.14*ra