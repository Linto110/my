def rectarea(l,b):
    return l*b
def rectperiarea(l,b):
    return 2*(l+b)