<?php
// PHP block to define arrays
$name = ["Rohit Sharma", "Virat Kohli","Subman gill","Mohammed shami","Rithuraj gaikwad","Jasprit bumbrah","Ravindra jadeja",""];
$role = ["Batsman (C)", "Batsman", ...];
?>
<table border="1">
    <tr>
        <th>No.</th>
        <th>Player Name</th>
        <th>Role</th>
    </tr>
    <?php
    // PHP block to generate table rows
    for ($i = 0; $i < count($name); $i++) {
        echo "<tr><td>" . ($i + 1) . "</td><td>" . $name[$i] . "</td><td>" . $role[$i] . "</td></tr>";
    }
    ?>
</table>
